function Favourite() {
    return <h2>Favourite page</h2>;
}

export default Favourite;
