export { default } from './SearchResult';
