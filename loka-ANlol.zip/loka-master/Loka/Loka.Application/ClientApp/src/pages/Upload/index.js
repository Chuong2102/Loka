function Upload() {
    return <h2>Upload page</h2>;
}

export default Upload;
