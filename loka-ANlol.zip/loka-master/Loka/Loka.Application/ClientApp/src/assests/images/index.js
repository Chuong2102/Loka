const images = {
    logo: require('~/assests/images/logo.svg').default,
    noImage: require('~/assests/images/no-image.png'),
};

export default images;
