﻿namespace Loka.Infrastructure.DapperQueries
{
    public class RoomQuery
    {
        public static string AllRooms => "select * from Rooms";
    }
}
